package com.vehiclelicenseapp.licenseapplication.entity;

public enum ApplicationStatus {
	PENDING,
	APPROVED,
	REJECTED;

}
