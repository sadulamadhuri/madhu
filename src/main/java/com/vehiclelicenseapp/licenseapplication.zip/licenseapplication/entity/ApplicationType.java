package com.vehiclelicenseapp.licenseapplication.entity;

public enum ApplicationType {
	LL,
	DL;
}
