package com.vehiclelicenseapp.licenseapplication.entity;

public enum Gender {
	MALE,
	FEMALE,
	OTHER;
}
