package com.vehiclelicenseapp.licenseapplication;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LicenseapplicationApplication {

	public static void main(String[] args) {
		SpringApplication.run(LicenseapplicationApplication.class, args);
	}

}
